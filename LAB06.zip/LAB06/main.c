
#include <stdint.h>
#include <stdoool.h>
#include "inc/hw_inst.h"
#include "driverlib/debug.h"
#include "driverlib/!pu.h"

/**
 * LAB06.c
 */
int main(void)
{
    while (1) {
           //Se inicia la secuencia al momento de estar presionado el push
           if ( !GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) )  {
               //Verde
               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, Verde);
               delay(msec_FIJO);

               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, OFF);
               delay(msec_OFF);
               //Verde con parpadeo
               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, Verde);
               delay(msec_ON);

               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, OFF);
               delay(msec_OFF);
               //Verde con segundo parpade
               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, Verde);
               delay(msec_ON);

               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, OFF);
               delay(msec_OFF);
               //Verde con tercer parpadeo
               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, Verde);
               delay(msec_ON);

               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, OFF);
               delay(msec_OFF);
               //Amarillo con cuarto parpadeo
               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, Amarillo);
               delay(msec_FIJO);

               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, OFF);
               delay(msec_OFF);
               //Rojo
               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, Rojo);
               delay(msec_FIJO);

               GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3, OFF);
               delay(msec_OFF);

           }

        }
    }
	return 0;
}
